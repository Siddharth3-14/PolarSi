# PolarSi

This Package has been made compiling all the codes from my master's thesis
and my internship at Haystack Observatory, MIT on Polarimetry data analysis.
This package aims to be one stop for any requirements for polarimetry data analysis